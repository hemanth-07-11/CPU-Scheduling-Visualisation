# CPU-Scheduling-Visualisation

This is an attempt at simulating CPU Scheduling algorithms - FCFS, SJF, RR, Priority Scheduling.

# Demo of the application 

 https://hemanthnprojects.000webhostapp.com/CPU_Scheduling/
 
 # Contributions
 
 Feel free to contribute to the UI and also any additional functionalites if it needs to be added.
